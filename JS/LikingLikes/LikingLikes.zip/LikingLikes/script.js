function likea() {
    likenum = document.querySelector("#like-a span");
    var likes = parseInt(likenum.textContent);
    likenum.textContent = likes + 1;
}

function likeb() {
    likenum = document.querySelector("#like-b span");
    var likes = parseInt(likenum.textContent);
    likenum.textContent = likes + 1;
}

function likec() {
    likenum = document.querySelector("#like-c span");
    var likes = parseInt(likenum.textContent);
    likenum.textContent = likes + 1;
}
